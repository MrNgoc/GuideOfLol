//
//  ImageDto.swift
//  GuideOfLol
//
//  Created by Le Ha Thanh on 8/3/16.
//  Copyright © 2016 MrNgoc. All rights reserved.
//
import UIKit
class ImageDto {
    var full: String?
    var group: String?
    var h: Int?
    var spite: String?
    var w: Int?
    var x: Int?
    var y: Int?
    
    init(full: String) {
        self.full = full
    }
    
}
