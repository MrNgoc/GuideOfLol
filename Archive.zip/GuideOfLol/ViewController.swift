//
//  ViewController.swift
//  GuideOfLol
//
//  Created by Admin on 8/2/16.
//  Copyright © 2016 MrNgoc. All rights reserved.
//

import UIKit
import SwiftyJSON


class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    
    @IBOutlet weak var myCollection: UICollectionView!
    
    var champions = [ChampionDto]()
    var champ : ChampionDto?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
        myCollection.backgroundColor = UIColor.whiteColor()
        
    }
    
    // lay anh + ten + id
    
    func getData() {
        
        let urlRequest = NSMutableURLRequest(URL: NSURL(string: "https://global.api.pvp.net/api/lol/static-data/na/v1.2/champion?champData=image&api_key=RGAPI-905251DD-5545-48D0-9598-0E601CA5E9AF")!)
        
        let session = NSURLSession.sharedSession()
        
        session.dataTaskWithRequest(urlRequest) { (data, response, error) in
            if let error = error {
                print(error.localizedDescription)
            }else{
                if let responseHTTP = response as? NSHTTPURLResponse{
                    if responseHTTP.statusCode == 200 {
                        
                        let json = JSON(data:data!)
                        let data = json["data"]
                        
                        var nameImage = "http://ddragon.leagueoflegends.com/cdn/6.12.1/img/champion/"
                        
                        for (key,subJson):(String, JSON) in data {
                            let idChamp = subJson["id"].intValue
                            let champion =  ChampionDto(id: idChamp, name: key, image: nameImage+String(key)+".png")
                            self.champions.append(champion)
                            
                        }
                        
                        self.printChampions(self.champions)
                        
                        dispatch_async(dispatch_get_main_queue(),{self.myCollection.reloadData()})
                    }
                }
            }
            
            }.resume()
        
    }
    func printChampions(champs: [ChampionDto])
    {
        champions = champs
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // print(champions.count)
        return champions.count
        
    }
    
    
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("cell", forIndexPath: indexPath) as! CellItem
        
        let imageURL = champions[indexPath.item].image
        
        //        var imageURL = champions[indexPath.item].nameImg
        let url = NSURL(string: imageURL!)
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0)) {
            let data = NSData(contentsOfURL: url!)
            
            dispatch_async(dispatch_get_main_queue(), {
                if let realData = data  {
                    cell.imageView.image = UIImage(data: realData)
                }
            })
        }
        
        if let name = champions[indexPath.item].name {
            cell.nameLabel.text = name
        }
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        let v1 = storyboard?.instantiateViewControllerWithIdentifier("Master") as? MasterTableVC
        
        getDataOfChampion(champions[indexPath.item].id!, masterVC: v1!)
    }
    
    func getDataOfChampion(idChamp : Int, masterVC : MasterTableVC) {
        let urlRequest = NSMutableURLRequest(URL: NSURL(string: "https://global.api.pvp.net/api/lol/static-data/na/v1.2/champion/\(idChamp)?champData=all&api_key=RGAPI-905251DD-5545-48D0-9598-0E601CA5E9AF")!)
        
        let session = NSURLSession.sharedSession()
        
        session.dataTaskWithRequest(urlRequest) { (data, response, error) in
            if let error = error {
                print(error.localizedDescription)
            }else{
                if let responseHTTP = response as? NSHTTPURLResponse{
                    if responseHTTP.statusCode == 200 {
                        
                        let json = JSON(data:data!)
                        // print(json)
                        // lay title
                        let titleChamp = json["title"].stringValue
                        
                        // lay allytips
                        let allytipsChamp = self.toString(json["allytips"])
                        
                        
                        let infoJSON  = json["info"]
                        let attack = infoJSON["attack"].intValue
                        let defense = infoJSON["defense"].intValue
                        let magic = infoJSON["magic"].intValue
                        let difficulty = infoJSON["difficulty"].intValue
                        
                        let infoChamp = InfoDto(attack: attack, defense: defense, difficulty: difficulty, magic: magic)
                        let tagsChamp = self.toString(json["tags"])
                        
                        //---------------------------------------- xong overview
                        
                        
                        let spellsChamp : ChampionSpellDto
                        for (key, spellJSON) in json["spells"] {
                            let name = spellJSON["name"].string
                            let costValue = self.toInt(spellJSON["cost"])
                            var cooldownBurnValue = spellJSON["cooldownBurn"].string
                            var rangeValue = self.toDouble(spellJSON["range"])
                            var descriptionValue = spellJSON["description"].string
                            
                            let spellsChamp = ChampionSpellDto(name: name!, cost: costValue, cooldownBurn: cooldownBurnValue!, range: rangeValue, description: descriptionValue!)
                            
                            print(name)
                        }
                        
                        
                        self.champ = ChampionDto(title: titleChamp, tags: tagsChamp, info: infoChamp, allytips: allytipsChamp)
                        
                        
                        //---------------------------------------- xong spells
                                                let statsChamp : StatsDto?
                        let statsJSON = json["stats"]
                        //                        print(statsJSON)
                        let hpValue = statsJSON["hp"].double
                        let hpperlevelValue = statsJSON["hpperlevel"].double
                        let hpregenValue = statsJSON["hpregen"].double
                        let hpregenperlevelValue = statsJSON["hpregenperlevel"].double
                        let armorValue = statsJSON["armor"].double
                        let armorperlevelValue = statsJSON["armorperlevel"].double
                        let attackdamageValue = statsJSON["attackdamage"].double
                        
                        let attackdamageperlevelValue = statsJSON["attackdamageperlevel"].double
                        let spellblockValue = statsJSON["spellblock"].double
                        let spellblockperlevelValue = statsJSON["spellblockperlevel"].double
                        let movespeedValue = statsJSON["movespeed"].double
                        
                        statsChamp = StatsDto(hp: hpValue!, hpperlevel: hpperlevelValue!,
                                              hpregen: hpregenValue!, hpregenperlevel: hpregenperlevelValue!,
                                              armor: armorValue!, armorperlevel: armorperlevelValue!,
                                              attackdamage: attackdamageValue!, attackdamageperlevel: attackdamageperlevelValue!,
                                              spellblock: spellblockValue!, spellblockperlevel: spellblockValue!,
                                              movespeed: movespeedValue!)
                        
                        print(statsChamp?.armor)
                        masterVC.champ = self.champ
                        
                        dispatch_async(dispatch_get_main_queue(), {
                            self.navigationController?.pushViewController(masterVC, animated: true)
                        })
                        
                        
                    }
                }
            }
            
            }.resume()
        
    }
    
    func toString(des: JSON) -> [String] {
        var text : [String] = []
        for i in des {
            text.append(i.1.string!)
        }
        
        return text
    }
    
    func toInt(des: JSON) -> [Int] {
        var text : [Int] = []
        for i in des {
            text.append(i.1.int!)
        }
        
        return text
    }
    
    func toDouble(des: JSON) -> [Double] {
        var text : [Double] = []
        for i in des {
            text.append(i.1.double!)
        }
        
        return text
    }
    
    
}
